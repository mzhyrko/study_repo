#[derive(Debug, Clone)]
pub struct Point {
    pub x: f64,
    pub y: f64,
}

// Kolor RGB
#[derive(Debug, Clone)]
pub struct Color {
    pub r: u8,
    pub g: u8,
    pub b: u8,
}

impl Color {
    pub fn new(r: u8, g: u8, b: u8) -> Self {
        Color { r, g, b }
    }
    
    pub fn from_name(name: &str) -> Self {
        match name.to_lowercase().as_str() {
            "red" => Color::new(255, 0, 0),
            "green" => Color::new(0, 255, 0),
            "blue" => Color::new(0, 0, 255),
            "yellow" => Color::new(255, 255, 0),
            "orange" => Color::new(255, 165, 0),
            "purple" => Color::new(128, 0, 128),
            "black" => Color::new(0, 0, 0),
            "white" => Color::new(255, 255, 255),
            "brown" => Color::new(165, 42, 42),
            "pink" => Color::new(255, 192, 203),
            "gray" | "grey" => Color::new(128, 128, 128),
            _ => Color::new(0, 0, 0), // domyślnie czarny
        }
    }
    
    pub fn from_number(n: f64) -> Self {
        let palette = [
            Color::new(0, 0, 0),       
            Color::new(0, 0, 255),     
            Color::new(0, 255, 0),     
            Color::new(0, 255, 255),   
            Color::new(255, 0, 0),     
            Color::new(255, 0, 255),   
            Color::new(255, 255, 0),   
            Color::new(255, 255, 255), 
        ];
        
        let index = (n as usize) % palette.len();
        palette[index].clone()
    }
    
    pub fn to_hex(&self) -> String {
        format!("#{:02x}{:02x}{:02x}", self.r, self.g, self.b)
    }
}

#[derive(Debug, Clone)]
pub struct Line {
    pub start: Point,
    pub end: Point,
    pub color: Color,
    pub width: f64,
}

#[derive(Debug, Clone)]
pub struct Label {
    pub position: Point,
    pub text: String,
    pub color: Color,
}

pub struct Turtle {
    pub x: f64,
    pub y: f64,
    pub heading: f64, // stopnie, 0 = polnoc, 90 = wschod
    pub pen_down: bool,
    pub pen_color: Color,
    pub pen_size: f64,
    pub visible: bool,
    pub lines: Vec<Line>,
    pub labels: Vec<Label>,
}

impl Turtle {
    pub fn new() -> Self {
        Turtle {
            x: 0.0,
            y: 0.0,
            heading: 0.0,
            pen_down: true,
            pen_color: Color::new(0, 0, 0),
            pen_size: 1.0,
            visible: true,
            lines: Vec::new(),
            labels: Vec::new(),
        }
    }
    
    pub fn forward(&mut self, distance: f64) {
        let angle_rad = (90.0 - self.heading) * std::f64::consts::PI / 180.0;
        let new_x = self.x + distance * angle_rad.cos();
        let new_y = self.y - distance * angle_rad.sin();
        
        if self.pen_down {
            self.lines.push(Line {
                start: Point { x: self.x, y: self.y },
                end: Point { x: new_x, y: new_y },
                color: self.pen_color.clone(),
                width: self.pen_size,
            });
        }
        
        self.x = new_x;
        self.y = new_y;
    }
    
    pub fn back(&mut self, distance: f64) {
        self.forward(-distance);
    }
    
    pub fn left(&mut self, angle: f64) {
        self.heading -= angle;
        self.heading = self.heading % 360.0;
    }
    
    pub fn right(&mut self, angle: f64) {
        self.heading += angle;
        self.heading = self.heading % 360.0;
    }
    
    // Podnosi pioro - zolw przestaje rysowac
    pub fn pen_up(&mut self) {
        self.pen_down = false;
    }

    // Opuszcza pioro - zolw zaczyna rysowac
    pub fn pen_down_cmd(&mut self) {
        self.pen_down = true;
    }

    // Ustawia kolor piora
    pub fn set_pen_color(&mut self, color: Color) {
        self.pen_color = color;
    }

    // Ustawia grubosc linii
    pub fn set_pen_size(&mut self, size: f64) {
        self.pen_size = size;
    }    pub fn home(&mut self) {
        let old_x = self.x;
        let old_y = self.y;
        
        self.x = 0.0;
        self.y = 0.0;
        self.heading = 0.0;
        
        if self.pen_down {
            self.lines.push(Line {
                start: Point { x: old_x, y: old_y },
                end: Point { x: 0.0, y: 0.0 },
                color: self.pen_color.clone(),
                width: self.pen_size,
            });
        }
    }
    
    pub fn clear_screen(&mut self) {
        self.lines.clear();
        self.labels.clear();
        self.x = 0.0;
        self.y = 0.0;
        self.heading = 0.0;
    }
    
    pub fn hide(&mut self) {
        self.visible = false;
    }
    
    pub fn show(&mut self) {
        self.visible = true;
    }
    
    pub fn set_xy(&mut self, x: f64, y: f64) {
        if self.pen_down {
            self.lines.push(Line {
                start: Point { x: self.x, y: self.y },
                end: Point { x, y },
                color: self.pen_color.clone(),
                width: self.pen_size,
            });
        }
        
        self.x = x;
        self.y = y;
    }
    
    pub fn set_x(&mut self, x: f64) {
        self.set_xy(x, self.y);
    }
    
    pub fn set_y(&mut self, y: f64) {
        self.set_xy(self.x, y);
    }
    
    pub fn set_heading(&mut self, angle: f64) {
        self.heading = angle % 360.0;
    }
    
    pub fn add_label(&mut self, text: String) {
        self.labels.push(Label {
            position: Point { x: self.x, y: self.y },
            text,
            color: self.pen_color.clone(),
        });
    }
    
    pub fn get_bounds(&self) -> (f64, f64, f64, f64) {
        if self.lines.is_empty() && self.labels.is_empty() {
            return (-100.0, -100.0, 100.0, 100.0);
        }
        
        let mut min_x: f64 = 0.0;
        let mut min_y: f64 = 0.0;
        let mut max_x: f64 = 0.0;
        let mut max_y: f64 = 0.0;
        
        for line in &self.lines {
            min_x = min_x.min(line.start.x).min(line.end.x);
            min_y = min_y.min(line.start.y).min(line.end.y);
            max_x = max_x.max(line.start.x).max(line.end.x);
            max_y = max_y.max(line.start.y).max(line.end.y);
        }
        
        for label in &self.labels {
            min_x = min_x.min(label.position.x);
            min_y = min_y.min(label.position.y);
            max_x = max_x.max(label.position.x);
            max_y = max_y.max(label.position.y);
        }
        
        // Dodaj margines
        let margin = 20.0;
        (min_x - margin, min_y - margin, max_x + margin, max_y + margin)
    }
}

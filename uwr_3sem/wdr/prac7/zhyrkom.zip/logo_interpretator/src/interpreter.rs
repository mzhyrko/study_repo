// Zarzadza stanem zolwia, zmiennymi i procedurami

use crate::parser::*;
use crate::turtle::{Turtle, Color};
use crate::svg_generator::SvgGenerator;
use anyhow::{Result, anyhow};
use std::collections::HashMap;

// Wyjatek sygnalizujacy zatrzymanie wykonania (komenda stop)
#[derive(Debug)]
struct StopExecution;

impl std::fmt::Display for StopExecution {
    fn fmt(&self, f: &mut std::fmt::Formatter) -> std::fmt::Result {
        write!(f, "Stop execution")
    }
}

impl std::error::Error for StopExecution {}

// Typ wartosci w jezyku LOGO (liczba, napis lub boolean)
#[derive(Debug, Clone)]
pub enum Value {
    Number(f64),      // Wartosc liczbowa
    String(String),   // Napis tekstowy
    Boolean(bool),    // Wartosc logiczna
}

impl Value {
    // Konwertuje wartosc do liczby
    pub fn as_number(&self) -> Result<f64> {
        match self {
            Value::Number(n) => Ok(*n),
            Value::String(s) => s.parse::<f64>()
                .map_err(|_| anyhow!("Cannot convert '{}' to number", s)),
            Value::Boolean(b) => Ok(if *b { 1.0 } else { 0.0 }),
        }
    }
    
    // Konwertuje wartosc do napisu
    pub fn as_string(&self) -> String {
        match self {
            Value::Number(n) => n.to_string(),
            Value::String(s) => s.clone(),
            Value::Boolean(b) => b.to_string(),
        }
    }
    
    // Konwertuje wartosc do boolean (0 i pusty napis = false)
    pub fn as_bool(&self) -> bool {
        match self {
            Value::Number(n) => *n != 0.0,
            Value::String(s) => !s.is_empty(),
            Value::Boolean(b) => *b,
        }
    }
}

// Definicja procedury uzytkownika
#[derive(Clone)]
struct Procedure {
    params: Vec<String>,      // Lista parametrow
    body: Vec<Statement>,     // Cialo procedury
}

pub struct Interpreter {
    turtle: Turtle,
    variables: HashMap<String, Value>,
    procedures: HashMap<String, Procedure>,
    repeat_count: Option<i32>,  // Licznik aktualnej petli repeat
}

impl Interpreter {
    // Tworzy nowy interpreter z pustym stanem
    pub fn new() -> Self {
        Interpreter {
            turtle: Turtle::new(),
            variables: HashMap::new(),
            procedures: HashMap::new(),
            repeat_count: None,
        }
    }
    
    // Wykonuje liste instrukcji (glowna petla interpretera)
    pub fn execute(&mut self, statements: &[Statement]) -> Result<()> {
        for statement in statements {
            match self.execute_statement(statement) {
                Ok(()) => {},
                Err(e) => {
                    // Jesli wystapila komenda stop, zakoncz normalnie
                    if e.downcast_ref::<StopExecution>().is_some() {
                        return Ok(());
                    }
                    return Err(e);
                }
            }
        }
        Ok(())
    }
    
    // Wykonuje pojedyncza instrukcje
    fn execute_statement(&mut self, statement: &Statement) -> Result<()> {
        match statement {
            Statement::Forward(expr) => {
                let distance = self.eval_expr(expr)?.as_number()?;
                self.turtle.forward(distance);
            }
            Statement::Back(expr) => {
                let distance = self.eval_expr(expr)?.as_number()?;
                self.turtle.back(distance);
            }
            Statement::Left(expr) => {
                let angle = self.eval_expr(expr)?.as_number()?;
                self.turtle.left(angle);
            }
            Statement::Right(expr) => {
                let angle = self.eval_expr(expr)?.as_number()?;
                self.turtle.right(angle);
            }
            Statement::PenUp => {
                self.turtle.pen_up();
            }
            Statement::PenDown => {
                self.turtle.pen_down_cmd();
            }
            Statement::SetPenColor(expr) => {
                let val = self.eval_expr(expr)?;
                let color = match val {
                    Value::Number(n) => Color::from_number(n),
                    Value::String(s) => Color::from_name(&s),
                    _ => Color::from_number(0.0),
                };
                self.turtle.set_pen_color(color);
            }
            Statement::SetPenSize(expr) => {
                let size = self.eval_expr(expr)?.as_number()?;
                self.turtle.set_pen_size(size);
            }
            Statement::Home => {
                self.turtle.home();
            }
            Statement::ClearScreen => {
                self.turtle.clear_screen();
            }
            Statement::HideTurtle => {
                self.turtle.hide();
            }
            Statement::ShowTurtle => {
                self.turtle.show();
            }
            Statement::SetXY(x_expr, y_expr) => {
                let x = self.eval_expr(x_expr)?.as_number()?;
                let y = self.eval_expr(y_expr)?.as_number()?;
                self.turtle.set_xy(x, y);
            }
            Statement::SetX(expr) => {
                let x = self.eval_expr(expr)?.as_number()?;
                self.turtle.set_x(x);
            }
            Statement::SetY(expr) => {
                let y = self.eval_expr(expr)?.as_number()?;
                self.turtle.set_y(y);
            }
            Statement::SetHeading(expr) => {
                let angle = self.eval_expr(expr)?.as_number()?;
                self.turtle.set_heading(angle);
            }
            Statement::Make(var, expr) => {
                let value = self.eval_expr(expr)?;
                self.variables.insert(var.clone(), value);
            }
            Statement::Print(expr) => {
                let value = self.eval_expr(expr)?;
                println!("{}", value.as_string());
            }
            Statement::Label(expr) => {
                let text = self.eval_expr(expr)?.as_string();
                self.turtle.add_label(text);
            }
            Statement::Stop => {
                return Err(anyhow::Error::new(StopExecution));
            }
            Statement::Repeat(count_expr, body) => {
                let count = self.eval_expr(count_expr)?.as_number()? as i32;
                for i in 1..=count {
                    let old_count = self.repeat_count;
                    self.repeat_count = Some(i);
                    let result = self.execute(body);
                    self.repeat_count = old_count;
                    result?;
                }
            }
            Statement::If(cond_expr, then_body, else_body) => {
                let condition = self.eval_expr(cond_expr)?.as_bool();
                if condition {
                    self.execute(then_body)?;
                } else if let Some(else_stmts) = else_body {
                    self.execute(else_stmts)?;
                }
            }
            Statement::ToDefinition(name, params, body) => {
                // Zapisz definicje procedury w mapie
                self.procedures.insert(
                    name.clone(),
                    Procedure {
                        params: params.clone(),
                        body: body.clone(),
                    },
                );
            }
            Statement::ProcedureCall(name, args) => {
                // Wywolaj procedure uzytkownika
                if let Some(proc) = self.procedures.get(name).cloned() {
                    let old_vars = self.variables.clone();
                    
                    // Podstaw argumenty jako zmienne lokalne
                    for (param, arg_expr) in proc.params.iter().zip(args.iter()) {
                        let value = self.eval_expr(arg_expr)?;
                        self.variables.insert(param.clone(), value);
                    }
                    
                    // Wykonaj cialo procedury
                    self.execute(&proc.body)?;
                    // Przywroc poprzednie zmienne (zakres lokalny)
                    self.variables = old_vars;
                } else {
                    return Err(anyhow!("Unknown procedure: {}", name));
                }
            }
        }
        Ok(())
    }
    
    // Oblicza wartosc wyrazenia (zwraca Value)
    fn eval_expr(&self, expr: &Expr) -> Result<Value> {
        match expr {
            Expr::Number(n) => Ok(Value::Number(*n)),
            Expr::String(s) => Ok(Value::String(s.clone())),
            Expr::Variable(name) => {
                self.variables.get(name)
                    .cloned()
                    .ok_or_else(|| anyhow!("Undefined variable: {}", name))
            }
            Expr::ColorName(name) => Ok(Value::String(name.clone())),
            Expr::UnaryMinus(expr) => {
                // Minus unarny - negacja wartosci
                let val = self.eval_expr(expr)?.as_number()?;
                Ok(Value::Number(-val))
            }
            Expr::BinaryOp(left, op, right) => {
                let left_val = self.eval_expr(left)?.as_number()?;
                let right_val = self.eval_expr(right)?.as_number()?;
                
                match op {
                    BinOp::Add => {
                        let l = left_val;
                        let r = right_val;
                        Ok(Value::Number(l + r))
                    }
                    BinOp::Sub => {
                        let l = left_val;
                        let r = right_val;
                        Ok(Value::Number(l - r))
                    }
                    BinOp::Mul => {
                        let l = left_val;
                        let r = right_val;
                        Ok(Value::Number(l * r))
                    }
                    BinOp::Div => {
                        let l = left_val;
                        let r = right_val;
                        if r == 0.0 {
                            return Err(anyhow!("Division by zero"));
                        }
                        Ok(Value::Number(l / r))
                    }
                    BinOp::Mod => {
                        let l = left_val;
                        let r = right_val;
                        Ok(Value::Number(l % r))
                    }
                    BinOp::Eq => {
                        let l = left_val;
                        let r = right_val;
                        Ok(Value::Boolean(l == r))
                    }
                    BinOp::Neq => {
                        let l = left_val;
                        let r = right_val;
                        Ok(Value::Boolean(l != r))
                    }
                    BinOp::Lt => {
                        let l = left_val;
                        let r = right_val;
                        Ok(Value::Boolean(l < r))
                    }
                    BinOp::Gt => {
                        let l = left_val;
                        let r = right_val;
                        Ok(Value::Boolean(l > r))
                    }
                    BinOp::Lte => {
                        let l = left_val;
                        let r = right_val;
                        Ok(Value::Boolean(l <= r))
                    }
                    BinOp::Gte => {
                        let l = left_val;
                        let r = right_val;
                        Ok(Value::Boolean(l >= r))
                    }
                }
            }
            Expr::FunctionCall(func, args) => self.eval_function(func, args),
        }
    }
    
    // Oblicza wartosc funkcji wbudowanej
    fn eval_function(&self, func: &Function, args: &[Expr]) -> Result<Value> {
        match func {
            // Funkcje matematyczne
            Function::Random => {
                // Losowa liczba od 0 do max-1
                let max = self.eval_expr(&args[0])?.as_number()?;
                let val = (rand::random::<f64>() * max).floor();
                Ok(Value::Number(val))
            }
            Function::Sqrt => {
                // Pierwiastek kwadratowy
                let val = self.eval_expr(&args[0])?.as_number()?;
                Ok(Value::Number(val.sqrt()))
            }
            Function::Sin => {
                // Sinus (kat w stopniach)
                let angle = self.eval_expr(&args[0])?.as_number()?;
                Ok(Value::Number(angle.to_radians().sin()))
            }
            Function::Cos => {
                // Cosinus (kat w stopniach)
                let angle = self.eval_expr(&args[0])?.as_number()?;
                Ok(Value::Number(angle.to_radians().cos()))
            }
            Function::Tan => {
                // Tangens (kat w stopniach)
                let angle = self.eval_expr(&args[0])?.as_number()?;
                Ok(Value::Number(angle.to_radians().tan()))
            }
            Function::Arctan => {
                // Arcus tangens (wynik w stopniach)
                let val = self.eval_expr(&args[0])?.as_number()?;
                Ok(Value::Number(val.atan().to_degrees()))
            }
            Function::Round => {
                // Zaokraglenie do najblizszej liczby calkowitej
                let val = self.eval_expr(&args[0])?.as_number()?;
                Ok(Value::Number(val.round()))
            }
            Function::Int => {
                // Czesc calkowita liczby
                let val = self.eval_expr(&args[0])?.as_number()?;
                Ok(Value::Number(val.trunc()))
            }
            // Funkcje napisowe
            Function::Word => {
                // Laczy dwa napisy w jeden
                let s1 = self.eval_expr(&args[0])?.as_string();
                let s2 = self.eval_expr(&args[1])?.as_string();
                Ok(Value::String(format!("{}{}", s1, s2)))
            }
            Function::First => {
                // Zwraca pierwszy znak napisu
                let s = self.eval_expr(&args[0])?.as_string();
                let first = s.chars().next().unwrap_or(' ').to_string();
                Ok(Value::String(first))
            }
            Function::Last => {
                // Zwraca ostatni znak napisu
                let s = self.eval_expr(&args[0])?.as_string();
                let last = s.chars().last().unwrap_or(' ').to_string();
                Ok(Value::String(last))
            }
            Function::Count => {
                // Zwraca dlugosc napisu
                let s = self.eval_expr(&args[0])?.as_string();
                Ok(Value::Number(s.len() as f64))
            }
            Function::Xcor => Ok(Value::Number(self.turtle.x)),
            Function::Ycor => Ok(Value::Number(self.turtle.y)),
            Function::Heading => Ok(Value::Number(self.turtle.heading)),
            Function::Repcount => {
                // Zwraca licznik aktualnej petli repeat
                match self.repeat_count {
                    Some(count) => Ok(Value::Number(count as f64)),
                    None => Err(anyhow!("repcount can only be used inside repeat loop")),
                }
            }
            Function::Pick => {
                // Losowy wybor z listy wyrazen
                if args.is_empty() {
                    return Err(anyhow!("pick requires at least one argument"));
                }
                let idx = (rand::random::<f64>() * args.len() as f64).floor() as usize;
                self.eval_expr(&args[idx])
            }
        }
    }
    
    pub fn save_svg(&self, filename: &str) -> Result<()> {
        let generator = SvgGenerator::new();
        generator.save(&self.turtle, filename)
    }
}

// Implementacja generatora liczb losowych
mod rand {
    use std::cell::Cell;
    
    thread_local! {
        static SEED: Cell<u64> = Cell::new(0x123456789abcdef0);
    }
    
    pub fn random<T: From<f64>>() -> T {
        SEED.with(|seed| {
            let mut s = seed.get();
            s ^= s << 13;
            s ^= s >> 7;
            s ^= s << 17;
            seed.set(s);
            T::from((s as f64) / (u64::MAX as f64))
        })
    }
}
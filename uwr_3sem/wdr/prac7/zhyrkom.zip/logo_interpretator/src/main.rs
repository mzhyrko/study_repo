// Interpreter jezyka LOGO z eksportem do SVG
// Projekt wykorzystuje parser PEST do analizy skladniowej

use anyhow::{Context, Result};
use std::env;
use std::fs;

// Moduly projektu
mod parser;         // Parsowanie kodu LOGO do AST
mod interpreter;    // Wykonywanie komend LOGO
mod turtle;         // Silnik grafiki zolwia
mod svg_generator;  // Generowanie grafiki SVG

use parser::Parser;
use interpreter::Interpreter;

// Glowna funkcja programu
fn main() -> Result<()> {
    // Pobierz argumenty z linii polecen
    let args: Vec<String> = env::args().collect();
    
    // Sprawdz poprawnosc liczby argumentow
    if args.len() < 2 {
        eprintln!("Usage: {} <logo_file> [output.svg]", args[0]);
        eprintln!("Example: {} program.logo output.svg", args[0]);
        std::process::exit(1);
    }
    
    let input_file = &args[1];
    let output_file = if args.len() >= 3 {
        args[2].clone()
    } else {
        "output.svg".to_string()
    };
    
    // Wczytaj plik zrodlowy LOGO
    let source = fs::read_to_string(input_file)
        .context(format!("Cannot read file: {}", input_file))?;
    
    // Parsuj kod LOGO do drzewa AST
    let parser = Parser::new();
    let ast = parser.parse(&source)
        .context("Parse error")?;
    
    // Stworz interpreter i wykonaj program
    let mut interpreter = Interpreter::new();
    interpreter.execute(&ast)
        .context("Execution error")?;
    
    // Zapisz wynik do pliku SVG
    interpreter.save_svg(&output_file)
        .context(format!("Cannot save SVG file: {}", output_file))?;
    
    Ok(())
}
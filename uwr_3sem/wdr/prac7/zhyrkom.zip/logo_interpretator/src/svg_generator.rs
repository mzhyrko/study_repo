// Modul do generowania plikow SVG z rysunkow zolwia
// Konwertuje linie i etykiety na format SVG

use crate::turtle::Turtle;
use anyhow::Result;
use svg::node::element::{Line, Path};
use svg::node::element::path::Data;
use svg::node::element::tag;
use svg::{Document, Node};
use std::fs::File;
use std::io::Write;

// Generator plikow SVG
pub struct SvgGenerator;

impl SvgGenerator {
    // Tworzy nowy generator SVG
    pub fn new() -> Self {
        SvgGenerator
    }
    
    // Zapisuje rysunek zolwia do pliku SVG
    pub fn save(&self, turtle: &Turtle, filename: &str) -> Result<()> {
        // Oblicz granice rysunku
        let (min_x, min_y, max_x, max_y) = turtle.get_bounds();
        let width = (max_x - min_x).max(100.0);
        let height = (max_y - min_y).max(100.0);
        
        // Stworz dokument SVG z odpowiednimi wymiarami
        let mut document = Document::new()
            .set("width", format!("{}px", width))
            .set("height", format!("{}px", height))
            .set("viewBox", format!("{} {} {} {}", min_x, min_y, width, height))
            .set("xmlns", "http://www.w3.org/2000/svg");
        
        // Dodaj biale tlo
        let background = svg::node::element::Rectangle::new()
            .set("x", min_x)
            .set("y", min_y)
            .set("width", width)
            .set("height", height)
            .set("fill", "white");
        document = document.add(background);
        
        // Dodaj wszystkie linie narysowane przez zolwia
        for line in &turtle.lines {
            let svg_line = Line::new()
                .set("x1", line.start.x)
                .set("y1", line.start.y)
                .set("x2", line.end.x)
                .set("y2", line.end.y)
                .set("stroke", line.color.to_hex())
                .set("stroke-width", line.width)
                .set("stroke-linecap", "round");
            
            document = document.add(svg_line);
        }
        
        // Dodaj etykiety tekstowe
        for label in &turtle.labels {
            let mut text = svg::node::element::Element::new(tag::Text);
            text.assign("x", label.position.x);
            text.assign("y", label.position.y);
            text.assign("fill", label.color.to_hex());
            text.assign("font-family", "Arial, sans-serif");
            text.assign("font-size", "12");
            text.append(svg::node::Text::new(&label.text));
            
            document = document.add(text);
        }
        
        // Opcjonalnie: narysuj zolwia jako trojkat
        if turtle.visible {
            let turtle_size = 10.0;
            
            // Oblicz pozycje wierzcholkow trojkata zolwia
            let angle_rad = (90.0 - turtle.heading) * std::f64::consts::PI / 180.0;
            
            // Przedni wierzcholek (grot)
            let front_x = turtle.x + turtle_size * angle_rad.cos();
            let front_y = turtle.y - turtle_size * angle_rad.sin();
            
            // Lewy tylny wierzcholek
            let left_angle = angle_rad + 2.5;
            let left_x = turtle.x - turtle_size * 0.6 * left_angle.cos();
            let left_y = turtle.y + turtle_size * 0.6 * left_angle.sin();
            
            // Prawy tylny wierzcholek
            let right_angle = angle_rad - 2.5;
            let right_x = turtle.x - turtle_size * 0.6 * right_angle.cos();
            let right_y = turtle.y + turtle_size * 0.6 * right_angle.sin();
            
            // Stworz sciezke SVG dla trojkata zolwia
            let path_data = Data::new()
                .move_to((front_x, front_y))
                .line_to((left_x, left_y))
                .line_to((right_x, right_y))
                .close();
            
            let turtle_path = Path::new()
                .set("d", path_data)
                .set("fill", "green")
                .set("stroke", "darkgreen")
                .set("stroke-width", 1.5);
            
            document = document.add(turtle_path);
        }
        
        // Zapisz dokument SVG do pliku
        let mut file = File::create(filename)?;
        write!(file, "{}", document)?;
        
        Ok(())
    }
}
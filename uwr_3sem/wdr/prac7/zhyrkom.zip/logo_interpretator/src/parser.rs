// Parser jezyka LOGO wykorzystujacy biblioteke PEST
// Konwertuje kod zrodlowy LOGO na drzewo Abstract Syntax Tree (AST)

use pest::Parser as PestParser;
use pest_derive::Parser;
use anyhow::{Result, anyhow};

// Struktura parsera wygenerowana przez PEST z gramatyki
#[derive(Parser)]
#[grammar = "logo.pest"]
pub struct LogoParser;

// Instrukcje jezyka LOGO
#[derive(Debug, Clone)]
pub enum Statement {
    Forward(Box<Expr>),      // Idz do przodu
    Back(Box<Expr>),         // Idz do tylu
    Left(Box<Expr>),         // Obroc w lewo
    Right(Box<Expr>),        // Obroc w prawo
    PenUp,                   // Podnies pioro
    PenDown,                 // Opusc pioro
    SetPenColor(Box<Expr>),  // Ustaw kolor piora
    SetPenSize(Box<Expr>),   // Ustaw grubosc linii
    Home,                    // Wroc do centrum (0,0)
    ClearScreen,             // Wyczysc ekran
    HideTurtle,              // Ukryj zolwia
    ShowTurtle,              // Pokaz zolwia
    SetXY(Box<Expr>, Box<Expr>),  // Ustaw pozycje X, Y
    SetX(Box<Expr>),         // Ustaw wspolrzedna X
    SetY(Box<Expr>),         // Ustaw wspolrzedna Y
    SetHeading(Box<Expr>),   // Ustaw kierunek w stopniach
    Make(String, Box<Expr>), // Przypisz wartosc do zmiennej
    Print(Box<Expr>),        // Wypisz wartosc na konsole
    Label(Box<Expr>),        // Dodaj etykiete tekstowa na rysunku
    Stop,                    // Zatrzymaj wykonywanie
    Repeat(Box<Expr>, Vec<Statement>),  // Petla repeat N razy
    If(Box<Expr>, Vec<Statement>, Option<Vec<Statement>>),  // Warunek if-else
    ProcedureCall(String, Vec<Expr>),    // Wywolanie procedury
    ToDefinition(String, Vec<String>, Vec<Statement>),  // Definicja procedury
}

// Wyrazenia w jezyku LOGO
#[derive(Debug, Clone)]
pub enum Expr {
    Number(f64),             // Liczba zmiennoprzecinkowa
    String(String),          // Napis tekstowy
    Variable(String),        // Odwolanie do zmiennej
    BinaryOp(Box<Expr>, BinOp, Box<Expr>),  // Operacja binarna
    UnaryMinus(Box<Expr>),   // Minus unarny
    FunctionCall(Function, Vec<Expr>),  // Wywolanie funkcji wbudowanej
    ColorName(String),       // Nazwa koloru (red, blue, etc.)
}

// Operatory binarne
#[derive(Debug, Clone)]
pub enum BinOp {
    Add, Sub, Mul, Div, Mod,         // Arytmetyczne: + - * / %
    Eq, Neq, Lt, Gt, Lte, Gte,       // Porownania: = <> < > <= >=
}

// Funkcje wbudowane
#[derive(Debug, Clone)]
pub enum Function {
    Random, Sqrt, Sin, Cos, Tan, Arctan,   // Matematyczne
    Round, Int, Word, First, Last, Count,   // Inne
    Xcor, Ycor, Heading,                    // Stan zolwia
    Repcount, Pick,                         // Dodatkowe funkcje
}

// Glowna struktura parsera
pub struct Parser;

impl Parser {
    // Tworzy nowy parser
    pub fn new() -> Self {
        Parser
    }
    
    // Parsuje kod LOGO do listy instrukcji AST
    pub fn parse(&self, source: &str) -> Result<Vec<Statement>> {
        // Uruchom parser PEST na kodzie zrodlowym
        let pairs = LogoParser::parse(Rule::program, source)
            .map_err(|e| anyhow!("Parse error: {}", e))?;
        
        let mut statements = Vec::new();
        
        // Przejdz przez wszystkie pary z parsera
        for pair in pairs {
            if pair.as_rule() == Rule::program {
                for inner in pair.into_inner() {
                    if inner.as_rule() == Rule::statement {
                        statements.push(self.parse_statement(inner)?);
                    }
                }
            }
        }
        
        Ok(statements)
    }
    
    // Parsuje pojedyncza instrukcje
    fn parse_statement(&self, pair: pest::iterators::Pair<Rule>) -> Result<Statement> {
        // Wyciagnij wewnetrzna regule (konkretny typ instrukcji)
        let inner = pair.into_inner().next().unwrap();
        
        match inner.as_rule() {
            Rule::command => self.parse_command(inner),
            Rule::repeat_stmt => self.parse_repeat(inner),
            Rule::if_stmt => self.parse_if(inner),
            Rule::to_definition => self.parse_to_definition(inner),
            Rule::make_stmt => self.parse_make(inner),
            Rule::setxy_stmt => self.parse_setxy(inner),
            Rule::setpencolor_stmt => {
                let expr = self.parse_expr(inner.into_inner().next().unwrap())?;
                Ok(Statement::SetPenColor(Box::new(expr)))
            }
            Rule::setpensize_stmt => {
                let expr = self.parse_expr(inner.into_inner().next().unwrap())?;
                Ok(Statement::SetPenSize(Box::new(expr)))
            }
            Rule::setx_stmt => {
                let expr = self.parse_expr(inner.into_inner().next().unwrap())?;
                Ok(Statement::SetX(Box::new(expr)))
            }
            Rule::sety_stmt => {
                let expr = self.parse_expr(inner.into_inner().next().unwrap())?;
                Ok(Statement::SetY(Box::new(expr)))
            }
            Rule::setheading_stmt => {
                let expr = self.parse_expr(inner.into_inner().next().unwrap())?;
                Ok(Statement::SetHeading(Box::new(expr)))
            }
            Rule::forward_stmt => {
                let expr = self.parse_expr(inner.into_inner().next().unwrap())?;
                Ok(Statement::Forward(Box::new(expr)))
            }
            Rule::back_stmt => {
                let expr = self.parse_expr(inner.into_inner().next().unwrap())?;
                Ok(Statement::Back(Box::new(expr)))
            }
            Rule::left_stmt => {
                let expr = self.parse_expr(inner.into_inner().next().unwrap())?;
                Ok(Statement::Left(Box::new(expr)))
            }
            Rule::right_stmt => {
                let expr = self.parse_expr(inner.into_inner().next().unwrap())?;
                Ok(Statement::Right(Box::new(expr)))
            }
            Rule::print_stmt_top => {
                let expr = self.parse_expr(inner.into_inner().next().unwrap())?;
                Ok(Statement::Print(Box::new(expr)))
            }
            Rule::label_stmt_top => {
                let expr = self.parse_expr(inner.into_inner().next().unwrap())?;
                Ok(Statement::Label(Box::new(expr)))
            }
            Rule::wait_stmt => {
                // Ignorujemy wait - po prostu nie robimy nic
                Ok(Statement::ClearScreen)  // Dummy statement
            }
            Rule::setlabelheight_stmt => {
                // Ignorujemy setlabelheight - po prostu nie robimy nic
                Ok(Statement::ClearScreen)  // Dummy statement
            }
            Rule::procedure_call => self.parse_procedure_call(inner),
            _ => Err(anyhow!("Unknown statement type")),
        }
    }
    
    // Parsuje komendy bez argumentow (penup, pendown, etc.)
    fn parse_command(&self, pair: pest::iterators::Pair<Rule>) -> Result<Statement> {
        let inner = pair.into_inner().next().unwrap();
        
        match inner.as_rule() {
            Rule::penup => Ok(Statement::PenUp),
            Rule::pendown => Ok(Statement::PenDown),
            Rule::home => Ok(Statement::Home),
            Rule::clearscreen => Ok(Statement::ClearScreen),
            Rule::hideturtle => Ok(Statement::HideTurtle),
            Rule::showturtle => Ok(Statement::ShowTurtle),
            Rule::stop => Ok(Statement::Stop),
            Rule::window => Ok(Statement::ClearScreen),  // Ignorujemy window
            _ => Err(anyhow!("Unknown command")),
        }
    }
    
    // Parsuje instrukcje setxy (ustaw pozycje X, Y)
    fn parse_setxy(&self, pair: pest::iterators::Pair<Rule>) -> Result<Statement> {
        let mut parts = pair.into_inner();
        let x = self.parse_expr(parts.next().unwrap())?;
        let y = self.parse_expr(parts.next().unwrap())?;
        Ok(Statement::SetXY(Box::new(x), Box::new(y)))
    }
    
    // Parsuje instrukcje make (przypisanie zmiennej)
    fn parse_make(&self, pair: pest::iterators::Pair<Rule>) -> Result<Statement> {
        let mut parts = pair.into_inner();
        let var_expr = self.parse_expr(parts.next().unwrap())?;
        let var_name = match var_expr {
            Expr::String(s) => s,
            _ => return Err(anyhow!("MAKE requires variable name as string")),
        };
        let expr = self.parse_expr(parts.next().unwrap())?;
        Ok(Statement::Make(var_name, Box::new(expr)))
    }
    
    // Parsuje petle repeat
    fn parse_repeat(&self, pair: pest::iterators::Pair<Rule>) -> Result<Statement> {
        let mut inner = pair.into_inner();
        let count = self.parse_expr(inner.next().unwrap())?;
        let mut body = Vec::new();
        
        for stmt_pair in inner {
            if stmt_pair.as_rule() == Rule::statement {
                body.push(self.parse_statement(stmt_pair)?);
            }
        }
        
        Ok(Statement::Repeat(Box::new(count), body))
    }
    
    // Parsuje instrukcje warunkowa if
    fn parse_if(&self, pair: pest::iterators::Pair<Rule>) -> Result<Statement> {
        let mut inner = pair.into_inner();
        let condition = self.parse_expr(inner.next().unwrap())?;
        
        let mut then_body = Vec::new();
        let mut else_body = None;
        let mut in_else = false;
        
        for stmt_pair in inner {
            if stmt_pair.as_rule() == Rule::statement {
                if in_else {
                    else_body.get_or_insert(Vec::new()).push(self.parse_statement(stmt_pair)?);
                } else {
                    then_body.push(self.parse_statement(stmt_pair)?);
                }
            } else if stmt_pair.as_str().to_lowercase() == "else" {
                in_else = true;
            }
        }
        
        Ok(Statement::If(Box::new(condition), then_body, else_body))
    }
    
    // Parsuje definicje procedury (to nazwa parametry ... end)
    fn parse_to_definition(&self, pair: pest::iterators::Pair<Rule>) -> Result<Statement> {
        let mut inner = pair.into_inner();
        let name = inner.next().unwrap().as_str().to_string();
        
        let mut params = Vec::new();
        let mut body = Vec::new();
        
        for item in inner {
            match item.as_rule() {
                Rule::param_list => {
                    for param in item.into_inner() {
                        if param.as_rule() == Rule::ident {
                            params.push(param.as_str().to_string());
                        }
                    }
                }
                Rule::statement => {
                    body.push(self.parse_statement(item)?);
                }
                _ => {}
            }
        }
        
        Ok(Statement::ToDefinition(name, params, body))
    }
    
    // Parsuje wywolanie procedury uzytkownika
    fn parse_procedure_call(&self, pair: pest::iterators::Pair<Rule>) -> Result<Statement> {
        let mut inner = pair.into_inner();
        let name = inner.next().unwrap().as_str().to_string();
        let mut args = Vec::new();
        
        for arg in inner {
            args.push(self.parse_expr(arg)?);
        }
        
        Ok(Statement::ProcedureCall(name, args))
    }
    
    // Parsuje wyrazenie (liczba, zmienna, operacja)
    fn parse_expr(&self, pair: pest::iterators::Pair<Rule>) -> Result<Expr> {
        match pair.as_rule() {
            Rule::expr | Rule::comparison | Rule::arithmetic | Rule::term => {
                self.parse_binary_expr(pair)
            }
            Rule::factor => self.parse_factor(pair),
            _ => Err(anyhow!("Unexpected expression type: {:?}", pair.as_rule())),
        }
    }
    
    // Parsuje wyrazenie binarne z operatorami (+, -, *, /, etc.)
    fn parse_binary_expr(&self, pair: pest::iterators::Pair<Rule>) -> Result<Expr> {
        let mut inner = pair.into_inner();
        let mut left = self.parse_expr(inner.next().unwrap())?;
        
        while let Some(op_pair) = inner.next() {
            let op = match op_pair.as_str() {
                "+" => BinOp::Add,
                "-" => BinOp::Sub,
                "*" => BinOp::Mul,
                "/" => BinOp::Div,
                "%" => BinOp::Mod,
                "=" => BinOp::Eq,
                "<>" => BinOp::Neq,
                "<" => BinOp::Lt,
                ">" => BinOp::Gt,
                "<=" => BinOp::Lte,
                ">=" => BinOp::Gte,
                _ => return Err(anyhow!("Unknown operator: {}", op_pair.as_str())),
            };
            
            let right = self.parse_expr(inner.next().unwrap())?;
            left = Expr::BinaryOp(Box::new(left), op, Box::new(right));
        }
        
        Ok(left)
    }
    
    // Parsuje faktor (liczba, zmienna, napis, wywolanie funkcji)
    fn parse_factor(&self, pair: pest::iterators::Pair<Rule>) -> Result<Expr> {
        let inner = pair.into_inner().next().unwrap();
        
        match inner.as_rule() {
            Rule::number => {
                let val = inner.as_str().parse::<f64>()
                    .map_err(|_| anyhow!("Number parse error"))?;
                Ok(Expr::Number(val))
            }
            Rule::string => {
                let s = inner.as_str();
                // Usun cudzyslow z poczatku (i z konca jesli jest)
                let trimmed = if s.starts_with('"') {
                    let without_start = &s[1..];
                    if without_start.ends_with('"') {
                        &without_start[..without_start.len()-1]
                    } else {
                        without_start
                    }
                } else {
                    s
                };
                Ok(Expr::String(trimmed.to_string()))
            }
            Rule::variable => {
                let var_name = inner.into_inner().next().unwrap().as_str().to_string();
                Ok(Expr::Variable(var_name))
            }
            Rule::color_name => {
                Ok(Expr::ColorName(inner.as_str().to_lowercase()))
            }
            Rule::unary_minus => {
                let expr = self.parse_expr(inner.into_inner().next().unwrap())?;
                Ok(Expr::UnaryMinus(Box::new(expr)))
            }
            Rule::function_call => self.parse_function_call(inner),
            Rule::expr => self.parse_expr(inner),
            _ => Err(anyhow!("Unknown factor type: {:?}", inner.as_rule())),
        }
    }
    
    // Parsuje wywolanie funkcji wbudowanej (random, sqrt, sin, etc.)
    fn parse_function_call(&self, pair: pest::iterators::Pair<Rule>) -> Result<Expr> {
        let inner = pair.into_inner().next().unwrap();
        
        let (func, args_iter) = match inner.as_rule() {
            Rule::random_fn => (Function::Random, inner.into_inner()),
            Rule::sqrt_fn => (Function::Sqrt, inner.into_inner()),
            Rule::sin_fn => (Function::Sin, inner.into_inner()),
            Rule::cos_fn => (Function::Cos, inner.into_inner()),
            Rule::tan_fn => (Function::Tan, inner.into_inner()),
            Rule::arctan_fn => (Function::Arctan, inner.into_inner()),
            Rule::round_fn => (Function::Round, inner.into_inner()),
            Rule::int_fn => (Function::Int, inner.into_inner()),
            Rule::word_fn => (Function::Word, inner.into_inner()),
            Rule::first_fn => (Function::First, inner.into_inner()),
            Rule::last_fn => (Function::Last, inner.into_inner()),
            Rule::count_fn => (Function::Count, inner.into_inner()),
            Rule::xcor_fn => (Function::Xcor, inner.into_inner()),
            Rule::ycor_fn => (Function::Ycor, inner.into_inner()),
            Rule::heading_fn => (Function::Heading, inner.into_inner()),
            Rule::repcount_fn => (Function::Repcount, inner.into_inner()),
            Rule::pick_fn => (Function::Pick, inner.into_inner()),
            _ => return Err(anyhow!("Unknown function")),
        };
        
        let args: Result<Vec<Expr>> = args_iter.map(|p| self.parse_expr(p)).collect();
        Ok(Expr::FunctionCall(func, args?))
    }
}
use std::fs::File;
use std::io::Write;
use std::ops::{Add, Sub, Mul};

// complex number implementation
#[derive(Clone, Copy, Debug)]
struct Complex {
    re: f64,
    im: f64,
}

impl Complex {
    fn new(re: f64, im: f64) -> Self {
        Complex { re, im }
    }

    // calculate magnitude squared (|z|^2)
    fn magnitude_squared(&self) -> f64 {
        self.re * self.re + self.im * self.im
    }
}

impl Add for Complex {
    type Output = Complex;

    fn add(self, other: Complex) -> Complex {
        Complex {
            re: self.re + other.re,
            im: self.im + other.im,
        }
    }
}

impl Sub for Complex {
    type Output = Complex;

    fn sub(self, other: Complex) -> Complex {
        Complex {
            re: self.re - other.re,
            im: self.im - other.im,
        }
    }
}

impl Mul for Complex {
    type Output = Complex;

    fn mul(self, other: Complex) -> Complex {
        Complex {
            re: self.re * other.re - self.im * other.im,
            im: self.re * other.im + self.im * other.re,
        }
    }
}

// ====================24-bit rgb Image===========================
struct Image {
    width: usize,
    height: usize,
    data: Vec<u8>, 
}

impl Image {
    fn new(width: usize, height: usize) -> Self {
        Image {
            width,
            height,
            data: vec![0; width * height * 3],
        }
    }

    // r, g, b values 0-255
    fn set_pixel(&mut self, x: usize, y: usize, r: u8, g: u8, b: u8) {
        if x < self.width && y < self.height {
            let index = (y * self.width + x) * 3;
            self.data[index] = r;
            self.data[index + 1] = g;
            self.data[index + 2] = b;
        }
    }

    // asve as ppm in text format
    fn save_ppm(&self, filename: &str) -> std::io::Result<()> {
        let mut file = File::create(filename)?;
        
        writeln!(file, "P3")?;
        writeln!(file, "{} {}", self.width, self.height)?;
        writeln!(file, "255")?;
        
        // write data to the file
        for y in 0..self.height {
            for x in 0..self.width {
                let index = (y * self.width + x) * 3;
                write!(file, "{} {} {} ", 
                    self.data[index], 
                    self.data[index + 1], 
                    self.data[index + 2])?;
            }
            writeln!(file)?;
        }
        
        Ok(())
    }
}

// ==========================Mandlebrot set calclation=====================================
fn mandelbrot(c: Complex, max_iterations: u32) -> u32 {
    let mut z = Complex::new(0.0, 0.0);
    let mut iterations = 0;

    while iterations < max_iterations && z.magnitude_squared() <= 4.0 {
        z = z * z + c;
        iterations += 1;
    }

    iterations
}

// Generate Mandelbrot fractal
fn generate_mandelbrot(
    width: usize,
    height: usize,
    x_min: f64,
    x_max: f64,
    y_min: f64,
    y_max: f64,
    max_iterations: u32,
) -> Image {
    let mut img = Image::new(width, height);

    for py in 0..height {
        for px in 0..width {
            // Map pixel coordinates to complex plane
            let x = x_min + (px as f64 / width as f64) * (x_max - x_min);
            let y = y_min + (py as f64 / height as f64) * (y_max - y_min);
            let c = Complex::new(x, y);

            let iterations = mandelbrot(c, max_iterations);

            // Color based on iterations
            let color = if iterations == max_iterations {
                (0, 0, 0)
            } else {
                let t = iterations as f64 / max_iterations as f64;
                let r = (9.0 * (1.0 - t) * t * t * t * 255.0) as u8;
                let g = (15.0 * (1.0 - t) * (1.0 - t) * t * t * 255.0) as u8;
                let b = (8.5 * (1.0 - t) * (1.0 - t) * (1.0 - t) * t * 255.0) as u8;
                (r, g, b)
            };

            img.set_pixel(px, py, color.0, color.1, color.2);
        }
    }

    img
}

fn main() {
    println!("Generating Mandelbrot fractal...");

    // Full Mandelbrot set
    let img1 = generate_mandelbrot(2048, 1080, -2.5, 1.0, -1.0, 1.0, 3000);
    img1.save_ppm("mandelbrot_full.ppm").expect("Failed to save image");
    println!("Saved: mandelbrot_full.ppm");
    println!("Done!");
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_mandelbrot_region_1() {
        let img = generate_mandelbrot(1920, 1080, -0.8, -0.7, 0.05, 0.15, 2000);
        img.save_ppm("test_mandelbrot_region_1.ppm").expect("Failed to save image");
    }

    #[test]
    fn test_mandelbrot_region_2() {
        let img = generate_mandelbrot(1920, 1080, 0.25, 0.35, -0.1, 0.0, 3500);
        img.save_ppm("test_mandelbrot_region_2.ppm").expect("Failed to save image");
    }

    #[test]
    fn test_mandelbrot_region_3() {
        let img = generate_mandelbrot(1920, 1080, -0.745, -0.735, 0.115, 0.125, 5000);
        img.save_ppm("test_mandelbrot_region_3.ppm").expect("Failed to save image");
    }

    #[test]
    fn test_mandelbrot_region_4() {
        let img = generate_mandelbrot(1920, 1080, -0.743643887037151, -0.743643887035151, 0.131825904205330, 0.131825904207330, 6000);
        img.save_ppm("test_mandelbrot_region_4.ppm").expect("Failed to save image");
    }

    #[test]
    fn test_mandelbrot_region_5() {
        let img = generate_mandelbrot(1920, 1080, -0.1, 0.05, 0.65, 0.70, 6500);
        img.save_ppm("test_mandelbrot_region_5.ppm").expect("Failed to save image");
    }
}
